import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import AdminLayout from "@/components/layout/admin-layout";
import { isUnauthorizedError } from "@/lib/authUtils";
import type { Post } from "@shared/schema";

export default function AdminPosts() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("");
  
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const queryClient = useQueryClient();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: posts = [], isLoading: postsLoading } = useQuery<Post[]>({
    queryKey: ["/api/admin/posts", { search, statusFilter, categoryFilter }],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (search) params.append('search', search);
      if (statusFilter) params.append('status', statusFilter);
      if (categoryFilter) params.append('category', categoryFilter);
      
      const response = await fetch(`/api/admin/posts?${params.toString()}`, {
        credentials: 'include',
      });
      
      if (!response.ok) throw new Error('Failed to fetch posts');
      return response.json();
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
    },
  });

  const { data: categories = [] } = useQuery({
    queryKey: ["/api/categories"],
  });

  const deletePostMutation = useMutation({
    mutationFn: async (postId: string) => {
      await apiRequest('DELETE', `/api/admin/posts/${postId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/posts"] });
      toast({
        title: "Success",
        description: "Post deleted successfully",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to delete post",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center" data-testid="loading-spinner">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-medium">Loading posts...</p>
        </div>
      </div>
    );
  }

  return (
    <AdminLayout>
      <div className="p-8">
        <div className="mb-8">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h1 className="text-3xl font-bold text-dark" data-testid="text-posts-title">Posts</h1>
              <p className="text-medium mt-2" data-testid="text-posts-subtitle">Manage your blog posts</p>
            </div>
            <a 
              href="/admin/posts/new"
              className="mt-4 sm:mt-0 bg-primary text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
              data-testid="button-new-post"
            >
              <i className="fas fa-plus mr-2"></i>New Post
            </a>
          </div>
        </div>

        {/* Filters and Search */}
        <div className="bg-white rounded-xl shadow-md p-6 mb-8" data-testid="section-filters">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <input 
                type="text" 
                placeholder="Search posts..." 
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                data-testid="input-search"
              />
            </div>
            <select 
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              data-testid="select-status-filter"
            >
              <option value="">All Status</option>
              <option value="published">Published</option>
              <option value="draft">Draft</option>
            </select>
            <select 
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              data-testid="select-category-filter"
            >
              <option value="">All Categories</option>
              {categories.map((category: any) => (
                <option key={category.id} value={category.id}>{category.name}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Posts Table */}
        <div className="bg-white rounded-xl shadow-md overflow-hidden" data-testid="section-posts-table">
          {postsLoading ? (
            <div className="p-8 text-center" data-testid="loading-posts">
              <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-primary mx-auto mb-4"></div>
              <p className="text-medium">Loading posts...</p>
            </div>
          ) : posts.length === 0 ? (
            <div className="p-8 text-center" data-testid="no-posts-message">
              <i className="fas fa-file-alt text-4xl text-gray-400 mb-4"></i>
              <h3 className="text-xl font-semibold text-dark mb-2">No posts found</h3>
              <p className="text-medium mb-6">
                {search || statusFilter || categoryFilter 
                  ? "Try adjusting your filters or search terms."
                  : "Create your first post to get started."
                }
              </p>
              <a 
                href="/admin/posts/new"
                className="bg-primary text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
                data-testid="button-create-first-post"
              >
                <i className="fas fa-plus mr-2"></i>Create First Post
              </a>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" data-testid="header-title">Title</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" data-testid="header-status">Status</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" data-testid="header-date">Date</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" data-testid="header-views">Views</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" data-testid="header-actions">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {posts.map((post) => (
                    <tr key={post.id} data-testid={`row-post-${post.id}`}>
                      <td className="px-6 py-4">
                        <div className="flex items-center">
                          {post.featuredImageUrl && (
                            <img 
                              src={post.featuredImageUrl} 
                              alt={post.title}
                              className="w-12 h-8 object-cover rounded mr-4"
                              data-testid="img-post-thumbnail"
                            />
                          )}
                          <div>
                            <p className="font-semibold text-dark" data-testid="text-post-title">{post.title}</p>
                            {post.excerpt && (
                              <p className="text-medium text-sm" data-testid="text-post-excerpt">
                                {post.excerpt.length > 60 ? `${post.excerpt.substring(0, 60)}...` : post.excerpt}
                              </p>
                            )}
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span 
                          className={`px-3 py-1 rounded-full text-sm font-medium ${
                            post.status === 'published' 
                              ? 'bg-green-100 text-green-800' 
                              : 'bg-yellow-100 text-yellow-800'
                          }`}
                          data-testid="badge-post-status"
                        >
                          {post.status === 'published' ? 'Published' : 'Draft'}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-medium" data-testid="text-post-date">
                        {new Date(post.publishedAt || post.createdAt).toLocaleDateString()}
                      </td>
                      <td className="px-6 py-4 text-medium" data-testid="text-post-views">
                        {post.viewCount || 0}
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex space-x-2">
                          <a 
                            href={`/admin/posts/edit/${post.id}`}
                            className="text-primary hover:text-blue-700"
                            data-testid="button-edit-post"
                          >
                            <i className="fas fa-edit"></i>
                          </a>
                          <button 
                            onClick={() => deletePostMutation.mutate(post.id)}
                            className="text-red-600 hover:text-red-800"
                            disabled={deletePostMutation.isPending}
                            data-testid="button-delete-post"
                          >
                            <i className="fas fa-trash"></i>
                          </button>
                          <a 
                            href={`/post/${post.slug}`}
                            className="text-medium hover:text-dark"
                            data-testid="button-view-post"
                          >
                            <i className="fas fa-eye"></i>
                          </a>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </AdminLayout>
  );
}
