import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import AdminLayout from "@/components/layout/admin-layout";
import { isUnauthorizedError } from "@/lib/authUtils";
import type { Settings } from "@shared/schema";

const colorSchemes = [
  { id: 'blue', name: 'Default Blue', colors: ['#2563EB', '#64748B', '#10B981'] },
  { id: 'green', name: 'Nature Green', colors: ['#10B981', '#64748B', '#2563EB'] },
  { id: 'purple', name: 'Creative Purple', colors: ['#7C3AED', '#64748B', '#EC4899'] },
];

const fontFamilies = [
  { id: 'inter', name: 'Inter (Current)' },
  { id: 'roboto', name: 'Roboto' },
  { id: 'opensans', name: 'Open Sans' },
  { id: 'lato', name: 'Lato' },
  { id: 'merriweather', name: 'Merriweather' },
];

export default function AdminSettings() {
  const [formData, setFormData] = useState({
    siteTitle: "",
    siteTagline: "",
    siteDescription: "",
    logoUrl: "",
    colorScheme: "blue",
    fontFamily: "inter",
    twitterUrl: "",
    facebookUrl: "",
    instagramUrl: "",
    linkedinUrl: "",
  });

  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const queryClient = useQueryClient();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: settings, isLoading: settingsLoading } = useQuery<Settings>({
    queryKey: ["/api/settings"],
    onSuccess: (settings) => {
      if (settings) {
        setFormData({
          siteTitle: settings.siteTitle || "",
          siteTagline: settings.siteTagline || "",
          siteDescription: settings.siteDescription || "",
          logoUrl: settings.logoUrl || "",
          colorScheme: settings.colorScheme || "blue",
          fontFamily: settings.fontFamily || "inter",
          twitterUrl: settings.twitterUrl || "",
          facebookUrl: settings.facebookUrl || "",
          instagramUrl: settings.instagramUrl || "",
          linkedinUrl: settings.linkedinUrl || "",
        });
      }
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
    },
  });

  const updateSettingsMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      return await apiRequest('PUT', '/api/admin/settings', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      toast({
        title: "Success",
        description: "Settings updated successfully",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update settings",
        variant: "destructive",
      });
    },
  });

  const uploadLogoMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append('file', file);
      
      const response = await fetch('/api/admin/upload', {
        method: 'POST',
        body: formData,
        credentials: 'include',
      });
      
      if (!response.ok) throw new Error('Upload failed');
      return response.json();
    },
    onSuccess: (data) => {
      setFormData(prev => ({ ...prev, logoUrl: data.url }));
      toast({
        title: "Success",
        description: "Logo uploaded successfully",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to upload logo",
        variant: "destructive",
      });
    },
  });

  const handleSave = () => {
    updateSettingsMutation.mutate(formData);
  };

  const handleLogoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      uploadLogoMutation.mutate(file);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center" data-testid="loading-spinner">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-medium">Loading settings...</p>
        </div>
      </div>
    );
  }

  return (
    <AdminLayout>
      <div className="p-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-dark" data-testid="text-settings-title">Settings</h1>
          <p className="text-medium mt-2" data-testid="text-settings-subtitle">Customize your blog's appearance and behavior</p>
        </div>

        <div className="max-w-4xl">
          {/* General Settings */}
          <div className="bg-white rounded-xl shadow-md p-6 mb-8" data-testid="section-general">
            <h2 className="text-xl font-bold text-dark mb-6" data-testid="text-general-title">General Settings</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-dark mb-2" data-testid="label-site-title">Site Title</label>
                <input 
                  type="text" 
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                  value={formData.siteTitle}
                  onChange={(e) => setFormData(prev => ({ ...prev, siteTitle: e.target.value }))}
                  data-testid="input-site-title"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-dark mb-2" data-testid="label-tagline">Tagline</label>
                <input 
                  type="text" 
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                  value={formData.siteTagline}
                  onChange={(e) => setFormData(prev => ({ ...prev, siteTagline: e.target.value }))}
                  data-testid="input-tagline"
                />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-dark mb-2" data-testid="label-description">Site Description</label>
                <textarea 
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary" 
                  rows={4}
                  value={formData.siteDescription}
                  onChange={(e) => setFormData(prev => ({ ...prev, siteDescription: e.target.value }))}
                  data-testid="textarea-description"
                />
              </div>
            </div>
          </div>

          {/* Appearance Settings */}
          <div className="bg-white rounded-xl shadow-md p-6 mb-8" data-testid="section-appearance">
            <h2 className="text-xl font-bold text-dark mb-6" data-testid="text-appearance-title">Appearance</h2>
            <div className="space-y-6">
              {/* Logo Upload */}
              <div>
                <label className="block text-sm font-medium text-dark mb-2" data-testid="label-logo">Site Logo</label>
                <div className="flex items-center space-x-4">
                  <div className="w-16 h-16 bg-primary rounded-lg flex items-center justify-center text-white font-bold text-xl" data-testid="logo-preview">
                    {formData.logoUrl ? (
                      <img src={formData.logoUrl} alt="Logo" className="w-full h-full object-cover rounded-lg" />
                    ) : (
                      formData.siteTitle?.substring(0, 2).toUpperCase() || "BP"
                    )}
                  </div>
                  <label className="cursor-pointer">
                    <span className="border border-gray-300 text-dark px-4 py-2 rounded-lg hover:bg-gray-50 transition-colors" data-testid="button-upload-logo">
                      {uploadLogoMutation.isPending ? "Uploading..." : "Upload New Logo"}
                    </span>
                    <input 
                      type="file" 
                      className="hidden" 
                      accept="image/*"
                      onChange={handleLogoUpload}
                      disabled={uploadLogoMutation.isPending}
                      data-testid="input-logo-upload"
                    />
                  </label>
                </div>
              </div>

              {/* Color Scheme */}
              <div>
                <label className="block text-sm font-medium text-dark mb-4" data-testid="label-color-scheme">Color Scheme</label>
                <div className="grid grid-cols-3 gap-4" data-testid="grid-color-schemes">
                  {colorSchemes.map((scheme) => (
                    <div 
                      key={scheme.id}
                      className={`p-4 border-2 rounded-lg cursor-pointer transition-colors ${
                        formData.colorScheme === scheme.id ? 'border-primary' : 'border-gray-300 hover:border-gray-400'
                      }`}
                      onClick={() => setFormData(prev => ({ ...prev, colorScheme: scheme.id }))}
                      data-testid={`color-scheme-${scheme.id}`}
                    >
                      <div className="flex space-x-2 mb-3">
                        {scheme.colors.map((color, index) => (
                          <div 
                            key={index}
                            className="w-6 h-6 rounded"
                            style={{ backgroundColor: color }}
                          />
                        ))}
                      </div>
                      <p className="text-sm font-medium">{scheme.name}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Typography */}
              <div>
                <label className="block text-sm font-medium text-dark mb-2" data-testid="label-font-family">Font Family</label>
                <select 
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                  value={formData.fontFamily}
                  onChange={(e) => setFormData(prev => ({ ...prev, fontFamily: e.target.value }))}
                  data-testid="select-font-family"
                >
                  {fontFamilies.map((font) => (
                    <option key={font.id} value={font.id}>{font.name}</option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Social Media */}
          <div className="bg-white rounded-xl shadow-md p-6 mb-8" data-testid="section-social">
            <h2 className="text-xl font-bold text-dark mb-6" data-testid="text-social-title">Social Media Links</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-dark mb-2" data-testid="label-twitter">Twitter</label>
                <input 
                  type="url" 
                  placeholder="https://twitter.com/yourusername" 
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                  value={formData.twitterUrl}
                  onChange={(e) => setFormData(prev => ({ ...prev, twitterUrl: e.target.value }))}
                  data-testid="input-twitter"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-dark mb-2" data-testid="label-facebook">Facebook</label>
                <input 
                  type="url" 
                  placeholder="https://facebook.com/yourpage" 
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                  value={formData.facebookUrl}
                  onChange={(e) => setFormData(prev => ({ ...prev, facebookUrl: e.target.value }))}
                  data-testid="input-facebook"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-dark mb-2" data-testid="label-instagram">Instagram</label>
                <input 
                  type="url" 
                  placeholder="https://instagram.com/yourusername" 
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                  value={formData.instagramUrl}
                  onChange={(e) => setFormData(prev => ({ ...prev, instagramUrl: e.target.value }))}
                  data-testid="input-instagram"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-dark mb-2" data-testid="label-linkedin">LinkedIn</label>
                <input 
                  type="url" 
                  placeholder="https://linkedin.com/in/yourprofile" 
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                  value={formData.linkedinUrl}
                  onChange={(e) => setFormData(prev => ({ ...prev, linkedinUrl: e.target.value }))}
                  data-testid="input-linkedin"
                />
              </div>
            </div>
          </div>

          {/* Save Button */}
          <div className="flex justify-end">
            <button 
              onClick={handleSave}
              className="bg-primary text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
              disabled={updateSettingsMutation.isPending}
              data-testid="button-save-settings"
            >
              {updateSettingsMutation.isPending ? "Saving..." : "Save Settings"}
            </button>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}
