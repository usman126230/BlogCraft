import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import AdminLayout from "@/components/layout/admin-layout";
import { isUnauthorizedError } from "@/lib/authUtils";

interface DashboardStats {
  totalPosts: number;
  publishedPosts: number;
  draftPosts: number;
  totalViews: number;
}

export default function AdminDashboard() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: stats, isLoading: statsLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/admin/dashboard/stats"],
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center" data-testid="loading-spinner">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-medium">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <AdminLayout>
      <div className="p-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-dark" data-testid="text-dashboard-title">Dashboard Overview</h1>
          <p className="text-medium mt-2" data-testid="text-dashboard-subtitle">Welcome back! Here's what's happening with your blog.</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8" data-testid="grid-stats-cards">
          <div className="bg-white rounded-xl shadow-md p-6" data-testid="card-total-posts">
            <div className="flex items-center">
              <div className="p-3 bg-blue-100 rounded-lg">
                <i className="fas fa-file-alt text-primary text-xl"></i>
              </div>
              <div className="ml-4">
                <p className="text-2xl font-bold text-dark" data-testid="text-total-posts">
                  {statsLoading ? "..." : stats?.totalPosts || 0}
                </p>
                <p className="text-medium text-sm">Total Posts</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-md p-6" data-testid="card-published-posts">
            <div className="flex items-center">
              <div className="p-3 bg-green-100 rounded-lg">
                <i className="fas fa-check-circle text-green-600 text-xl"></i>
              </div>
              <div className="ml-4">
                <p className="text-2xl font-bold text-dark" data-testid="text-published-posts">
                  {statsLoading ? "..." : stats?.publishedPosts || 0}
                </p>
                <p className="text-medium text-sm">Published</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-md p-6" data-testid="card-draft-posts">
            <div className="flex items-center">
              <div className="p-3 bg-yellow-100 rounded-lg">
                <i className="fas fa-edit text-yellow-600 text-xl"></i>
              </div>
              <div className="ml-4">
                <p className="text-2xl font-bold text-dark" data-testid="text-draft-posts">
                  {statsLoading ? "..." : stats?.draftPosts || 0}
                </p>
                <p className="text-medium text-sm">Drafts</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-md p-6" data-testid="card-total-views">
            <div className="flex items-center">
              <div className="p-3 bg-purple-100 rounded-lg">
                <i className="fas fa-eye text-purple-600 text-xl"></i>
              </div>
              <div className="ml-4">
                <p className="text-2xl font-bold text-dark" data-testid="text-total-views">
                  {statsLoading ? "..." : (stats?.totalViews || 0).toLocaleString()}
                </p>
                <p className="text-medium text-sm">Total Views</p>
              </div>
            </div>
          </div>
        </div>

        {/* Recent Activity & Analytics */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Recent Posts */}
          <div className="bg-white rounded-xl shadow-md p-6" data-testid="section-recent-posts">
            <h2 className="text-xl font-bold text-dark mb-4" data-testid="text-recent-posts-title">Recent Posts</h2>
            <div className="space-y-4">
              {statsLoading ? (
                [...Array(3)].map((_, i) => (
                  <div key={i} className="animate-pulse flex items-center p-3 bg-gray-50 rounded-lg">
                    <div className="flex-1">
                      <div className="h-4 bg-gray-300 rounded w-3/4 mb-2"></div>
                      <div className="h-3 bg-gray-300 rounded w-1/2"></div>
                    </div>
                    <div className="h-4 bg-gray-300 rounded w-16"></div>
                  </div>
                ))
              ) : (
                <div className="text-center py-8 text-medium" data-testid="text-no-posts">
                  <i className="fas fa-file-alt text-4xl mb-4 text-gray-400"></i>
                  <p>No posts yet</p>
                  <p className="text-sm">Create your first post to get started</p>
                  <a 
                    href="/admin/posts/new"
                    className="inline-block mt-4 bg-primary text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors"
                    data-testid="button-create-first-post"
                  >
                    Create First Post
                  </a>
                </div>
              )}
            </div>
          </div>

          {/* Analytics Chart Placeholder */}
          <div className="bg-white rounded-xl shadow-md p-6" data-testid="section-analytics">
            <h2 className="text-xl font-bold text-dark mb-4" data-testid="text-analytics-title">Views Analytics</h2>
            <div className="h-64 bg-gray-50 rounded-lg flex items-center justify-center">
              <div className="text-center text-medium" data-testid="placeholder-analytics">
                <i className="fas fa-chart-line text-4xl mb-4 text-gray-400"></i>
                <p>Analytics Chart</p>
                <p className="text-sm">View trends and engagement metrics</p>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="mt-8">
          <h2 className="text-xl font-bold text-dark mb-4" data-testid="text-quick-actions-title">Quick Actions</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4" data-testid="grid-quick-actions">
            <a 
              href="/admin/posts/new"
              className="bg-primary text-white p-6 rounded-xl hover:bg-blue-700 transition-colors"
              data-testid="button-new-post"
            >
              <i className="fas fa-plus text-2xl mb-2"></i>
              <h3 className="font-semibold">Create New Post</h3>
              <p className="text-sm text-blue-100">Start writing your next article</p>
            </a>
            
            <a 
              href="/admin/posts"
              className="bg-green-600 text-white p-6 rounded-xl hover:bg-green-700 transition-colors"
              data-testid="button-manage-posts"
            >
              <i className="fas fa-edit text-2xl mb-2"></i>
              <h3 className="font-semibold">Manage Posts</h3>
              <p className="text-sm text-green-100">Edit and organize your content</p>
            </a>
            
            <a 
              href="/admin/settings"
              className="bg-purple-600 text-white p-6 rounded-xl hover:bg-purple-700 transition-colors"
              data-testid="button-site-settings"
            >
              <i className="fas fa-cog text-2xl mb-2"></i>
              <h3 className="font-semibold">Site Settings</h3>
              <p className="text-sm text-purple-100">Customize your blog's appearance</p>
            </a>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}
