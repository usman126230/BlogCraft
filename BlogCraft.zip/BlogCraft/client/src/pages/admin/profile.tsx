import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import AdminLayout from "@/components/layout/admin-layout";
import { isUnauthorizedError } from "@/lib/authUtils";
import type { User } from "@shared/schema";

export default function AdminProfile() {
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    bio: "",
    jobTitle: "",
    website: "",
    displayName: "",
    twitterUrl: "",
    linkedinUrl: "",
    instagramUrl: "",
    githubUrl: "",
  });

  const { toast } = useToast();
  const { user, isAuthenticated, isLoading } = useAuth();
  const queryClient = useQueryClient();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Load user data into form
  useEffect(() => {
    if (user) {
      setFormData({
        firstName: user.firstName || "",
        lastName: user.lastName || "",
        email: user.email || "",
        bio: user.bio || "",
        jobTitle: user.jobTitle || "",
        website: user.website || "",
        displayName: user.displayName || "",
        twitterUrl: user.twitterUrl || "",
        linkedinUrl: user.linkedinUrl || "",
        instagramUrl: user.instagramUrl || "",
        githubUrl: user.githubUrl || "",
      });
    }
  }, [user]);

  const updateProfileMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      return await apiRequest('PUT', '/api/admin/profile', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      toast({
        title: "Success",
        description: "Profile updated successfully",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update profile",
        variant: "destructive",
      });
    },
  });

  const uploadAvatarMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append('file', file);
      
      const response = await fetch('/api/admin/upload', {
        method: 'POST',
        body: formData,
        credentials: 'include',
      });
      
      if (!response.ok) throw new Error('Upload failed');
      return response.json();
    },
    onSuccess: (data) => {
      // Update user profile with new avatar
      updateProfileMutation.mutate({
        ...formData,
        profileImageUrl: data.url
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to upload avatar",
        variant: "destructive",
      });
    },
  });

  const handleSave = () => {
    updateProfileMutation.mutate(formData);
  };

  const handleAvatarUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      uploadAvatarMutation.mutate(file);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center" data-testid="loading-spinner">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-medium">Loading profile...</p>
        </div>
      </div>
    );
  }

  return (
    <AdminLayout>
      <div className="p-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-dark" data-testid="text-profile-title">Profile Settings</h1>
          <p className="text-medium mt-2" data-testid="text-profile-subtitle">Manage your personal information and author profile</p>
        </div>

        <div className="max-w-4xl">
          {/* Profile Picture */}
          <div className="bg-white rounded-xl shadow-md p-6 mb-8" data-testid="section-profile-picture">
            <h2 className="text-xl font-bold text-dark mb-6" data-testid="text-picture-title">Profile Picture</h2>
            <div className="flex items-center space-x-6">
              <div className="w-24 h-24 rounded-full overflow-hidden bg-gray-300" data-testid="avatar-preview">
                {user?.profileImageUrl ? (
                  <img 
                    src={user.profileImageUrl} 
                    alt="Profile" 
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-white font-bold text-2xl">
                    {(user?.firstName?.[0] || user?.email?.[0] || 'U').toUpperCase()}
                  </div>
                )}
              </div>
              <div>
                <label className="cursor-pointer">
                  <span className="bg-primary text-white px-6 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors" data-testid="button-upload-avatar">
                    {uploadAvatarMutation.isPending ? "Uploading..." : "Upload New Picture"}
                  </span>
                  <input 
                    type="file" 
                    className="hidden" 
                    accept="image/*"
                    onChange={handleAvatarUpload}
                    disabled={uploadAvatarMutation.isPending}
                    data-testid="input-avatar-upload"
                  />
                </label>
                <p className="text-medium text-sm mt-2">JPG, PNG, or GIF. Max size 5MB.</p>
              </div>
            </div>
          </div>

          {/* Personal Information */}
          <div className="bg-white rounded-xl shadow-md p-6 mb-8" data-testid="section-personal-info">
            <h2 className="text-xl font-bold text-dark mb-6" data-testid="text-personal-title">Personal Information</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-dark mb-2" data-testid="label-first-name">First Name</label>
                <input 
                  type="text" 
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                  value={formData.firstName}
                  onChange={(e) => setFormData(prev => ({ ...prev, firstName: e.target.value }))}
                  data-testid="input-first-name"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-dark mb-2" data-testid="label-last-name">Last Name</label>
                <input 
                  type="text" 
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                  value={formData.lastName}
                  onChange={(e) => setFormData(prev => ({ ...prev, lastName: e.target.value }))}
                  data-testid="input-last-name"
                />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-dark mb-2" data-testid="label-email">Email</label>
                <input 
                  type="email" 
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary bg-gray-50" 
                  value={formData.email}
                  disabled
                  data-testid="input-email"
                />
                <p className="text-sm text-medium mt-1">Email cannot be changed</p>
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-dark mb-2" data-testid="label-bio">Bio</label>
                <textarea 
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary" 
                  rows={4}
                  placeholder="Tell us about yourself..."
                  value={formData.bio}
                  onChange={(e) => setFormData(prev => ({ ...prev, bio: e.target.value }))}
                  data-testid="textarea-bio"
                />
              </div>
            </div>
          </div>

          {/* Author Information */}
          <div className="bg-white rounded-xl shadow-md p-6 mb-8" data-testid="section-author-info">
            <h2 className="text-xl font-bold text-dark mb-6" data-testid="text-author-title">Author Information</h2>
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-dark mb-2" data-testid="label-display-name">Display Name</label>
                <input 
                  type="text" 
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                  placeholder="How your name appears on posts"
                  value={formData.displayName}
                  onChange={(e) => setFormData(prev => ({ ...prev, displayName: e.target.value }))}
                  data-testid="input-display-name"
                />
                <p className="text-medium text-sm mt-1">This name will appear on your published posts</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-dark mb-2" data-testid="label-job-title">Job Title</label>
                <input 
                  type="text" 
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                  placeholder="Senior Content Writer"
                  value={formData.jobTitle}
                  onChange={(e) => setFormData(prev => ({ ...prev, jobTitle: e.target.value }))}
                  data-testid="input-job-title"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-dark mb-2" data-testid="label-website">Website</label>
                <input 
                  type="url" 
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                  placeholder="https://yourwebsite.com"
                  value={formData.website}
                  onChange={(e) => setFormData(prev => ({ ...prev, website: e.target.value }))}
                  data-testid="input-website"
                />
              </div>
            </div>
          </div>

          {/* Social Links */}
          <div className="bg-white rounded-xl shadow-md p-6 mb-8" data-testid="section-social-links">
            <h2 className="text-xl font-bold text-dark mb-6" data-testid="text-social-links-title">Social Media Links</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-dark mb-2" data-testid="label-twitter-profile">
                  <i className="fab fa-twitter text-blue-500 mr-2"></i>Twitter
                </label>
                <input 
                  type="url" 
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                  placeholder="https://twitter.com/yourusername"
                  value={formData.twitterUrl}
                  onChange={(e) => setFormData(prev => ({ ...prev, twitterUrl: e.target.value }))}
                  data-testid="input-twitter-profile"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-dark mb-2" data-testid="label-linkedin-profile">
                  <i className="fab fa-linkedin text-blue-700 mr-2"></i>LinkedIn
                </label>
                <input 
                  type="url" 
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                  placeholder="https://linkedin.com/in/yourprofile"
                  value={formData.linkedinUrl}
                  onChange={(e) => setFormData(prev => ({ ...prev, linkedinUrl: e.target.value }))}
                  data-testid="input-linkedin-profile"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-dark mb-2" data-testid="label-instagram-profile">
                  <i className="fab fa-instagram text-pink-500 mr-2"></i>Instagram
                </label>
                <input 
                  type="url" 
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                  placeholder="https://instagram.com/yourusername"
                  value={formData.instagramUrl}
                  onChange={(e) => setFormData(prev => ({ ...prev, instagramUrl: e.target.value }))}
                  data-testid="input-instagram-profile"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-dark mb-2" data-testid="label-github-profile">
                  <i className="fab fa-github text-gray-800 mr-2"></i>GitHub
                </label>
                <input 
                  type="url" 
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                  placeholder="https://github.com/yourusername"
                  value={formData.githubUrl}
                  onChange={(e) => setFormData(prev => ({ ...prev, githubUrl: e.target.value }))}
                  data-testid="input-github-profile"
                />
              </div>
            </div>
          </div>

          {/* Save Button */}
          <div className="flex justify-end">
            <button 
              onClick={handleSave}
              className="bg-primary text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
              disabled={updateProfileMutation.isPending}
              data-testid="button-update-profile"
            >
              {updateProfileMutation.isPending ? "Updating..." : "Update Profile"}
            </button>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}
