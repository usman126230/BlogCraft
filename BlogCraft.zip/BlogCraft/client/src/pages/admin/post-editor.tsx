import { useState, useEffect } from "react";
import { useParams } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import AdminLayout from "@/components/layout/admin-layout";
import RichTextEditor from "@/components/rich-text-editor";
import { isUnauthorizedError } from "@/lib/authUtils";
import type { Post, Category } from "@shared/schema";

export default function AdminPostEditor() {
  const { id } = useParams<{ id?: string }>();
  const isEditing = !!id;
  
  const [formData, setFormData] = useState({
    title: "",
    content: "",
    excerpt: "",
    featuredImageUrl: "",
    status: "draft" as "draft" | "published",
    categoryId: "",
    metaTitle: "",
    metaDescription: "",
  });

  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const queryClient = useQueryClient();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: post, isLoading: postLoading } = useQuery<Post>({
    queryKey: ["/api/admin/posts", id],
    queryFn: async () => {
      const response = await fetch(`/api/admin/posts/${id}`, {
        credentials: 'include',
      });
      if (!response.ok) throw new Error('Failed to fetch post');
      return response.json();
    },
    enabled: isEditing,
    onSuccess: (post) => {
      setFormData({
        title: post.title,
        content: post.content || "",
        excerpt: post.excerpt || "",
        featuredImageUrl: post.featuredImageUrl || "",
        status: post.status || "draft",
        categoryId: post.categoryId || "",
        metaTitle: post.metaTitle || "",
        metaDescription: post.metaDescription || "",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
    },
  });

  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const savePostMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const url = isEditing ? `/api/admin/posts/${id}` : '/api/admin/posts';
      const method = isEditing ? 'PUT' : 'POST';
      
      return await apiRequest(method, url, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/posts"] });
      toast({
        title: "Success",
        description: `Post ${isEditing ? 'updated' : 'created'} successfully`,
      });
      
      if (!isEditing) {
        // Redirect to posts list after creating
        window.location.href = '/admin/posts';
      }
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: `Failed to ${isEditing ? 'update' : 'create'} post`,
        variant: "destructive",
      });
    },
  });

  const uploadImageMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append('file', file);
      
      const response = await fetch('/api/admin/upload', {
        method: 'POST',
        body: formData,
        credentials: 'include',
      });
      
      if (!response.ok) throw new Error('Upload failed');
      return response.json();
    },
    onSuccess: (data) => {
      setFormData(prev => ({ ...prev, featuredImageUrl: data.url }));
      toast({
        title: "Success",
        description: "Image uploaded successfully",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to upload image",
        variant: "destructive",
      });
    },
  });

  const handleSave = (status: "draft" | "published" = "draft") => {
    savePostMutation.mutate({ ...formData, status });
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      uploadImageMutation.mutate(file);
    }
  };

  if (isLoading || (isEditing && postLoading)) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center" data-testid="loading-spinner">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-medium">Loading editor...</p>
        </div>
      </div>
    );
  }

  return (
    <AdminLayout>
      <div className="p-8">
        <div className="mb-8">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h1 className="text-3xl font-bold text-dark" data-testid="text-editor-title">
                {isEditing ? 'Edit Post' : 'Create New Post'}
              </h1>
              <p className="text-medium mt-2" data-testid="text-editor-subtitle">
                {isEditing ? 'Update your content' : 'Write and publish your content'}
              </p>
            </div>
            <div className="flex space-x-3 mt-4 sm:mt-0">
              <button 
                onClick={() => handleSave("draft")}
                className="border border-gray-300 text-dark px-6 py-2 rounded-lg font-medium hover:bg-gray-50 transition-colors"
                disabled={savePostMutation.isPending}
                data-testid="button-save-draft"
              >
                Save Draft
              </button>
              <button 
                onClick={() => handleSave("published")}
                className="bg-primary text-white px-6 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors"
                disabled={savePostMutation.isPending}
                data-testid="button-publish"
              >
                {savePostMutation.isPending ? "Saving..." : "Publish"}
              </button>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Editor */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-md p-6" data-testid="section-main-editor">
              {/* Title Input */}
              <div className="mb-6">
                <input 
                  type="text" 
                  placeholder="Enter your post title..." 
                  className="w-full text-3xl font-bold border-none focus:outline-none focus:ring-0 placeholder-gray-400"
                  value={formData.title}
                  onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                  data-testid="input-post-title"
                />
              </div>

              {/* Featured Image Upload */}
              <div className="mb-6">
                {formData.featuredImageUrl ? (
                  <div className="relative" data-testid="section-featured-image">
                    <img 
                      src={formData.featuredImageUrl} 
                      alt="Featured" 
                      className="w-full h-48 object-cover rounded-lg"
                      data-testid="img-featured-preview"
                    />
                    <button
                      onClick={() => setFormData(prev => ({ ...prev, featuredImageUrl: "" }))}
                      className="absolute top-2 right-2 bg-red-600 text-white p-2 rounded-full hover:bg-red-700"
                      data-testid="button-remove-image"
                    >
                      <i className="fas fa-times"></i>
                    </button>
                  </div>
                ) : (
                  <label className="block">
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-primary transition-colors cursor-pointer" data-testid="dropzone-featured-image">
                      <i className="fas fa-image text-4xl text-gray-400 mb-4"></i>
                      <p className="text-medium font-medium mb-2">Click to upload featured image</p>
                      <p className="text-gray-400 text-sm">PNG, JPG, GIF up to 10MB</p>
                      {uploadImageMutation.isPending && (
                        <p className="text-primary mt-2">Uploading...</p>
                      )}
                    </div>
                    <input 
                      type="file" 
                      className="hidden" 
                      accept="image/*"
                      onChange={handleImageUpload}
                      disabled={uploadImageMutation.isPending}
                      data-testid="input-image-upload"
                    />
                  </label>
                )}
              </div>

              {/* Rich Text Editor */}
              <div className="mb-6">
                <RichTextEditor
                  value={formData.content}
                  onChange={(content) => setFormData(prev => ({ ...prev, content }))}
                  placeholder="Start writing your post..."
                />
              </div>

              {/* Excerpt */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-dark mb-2" data-testid="label-excerpt">Excerpt</label>
                <textarea 
                  placeholder="Brief description of your post..." 
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary" 
                  rows={3}
                  value={formData.excerpt}
                  onChange={(e) => setFormData(prev => ({ ...prev, excerpt: e.target.value }))}
                  data-testid="textarea-excerpt"
                />
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Publish Settings */}
            <div className="bg-white rounded-xl shadow-md p-6" data-testid="section-publish-settings">
              <h3 className="text-lg font-semibold text-dark mb-4" data-testid="text-publish-settings-title">Publish Settings</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-dark mb-2" data-testid="label-status">Status</label>
                  <select 
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                    value={formData.status}
                    onChange={(e) => setFormData(prev => ({ ...prev, status: e.target.value as "draft" | "published" }))}
                    data-testid="select-status"
                  >
                    <option value="draft">Draft</option>
                    <option value="published">Published</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Categories */}
            <div className="bg-white rounded-xl shadow-md p-6" data-testid="section-categories">
              <h3 className="text-lg font-semibold text-dark mb-4" data-testid="text-categories-title">Category</h3>
              <select 
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                value={formData.categoryId}
                onChange={(e) => setFormData(prev => ({ ...prev, categoryId: e.target.value }))}
                data-testid="select-category"
              >
                <option value="">Select a category</option>
                {categories.map((category) => (
                  <option key={category.id} value={category.id}>{category.name}</option>
                ))}
              </select>
            </div>

            {/* SEO Settings */}
            <div className="bg-white rounded-xl shadow-md p-6" data-testid="section-seo">
              <h3 className="text-lg font-semibold text-dark mb-4" data-testid="text-seo-title">SEO Settings</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-dark mb-2" data-testid="label-meta-title">Meta Title</label>
                  <input 
                    type="text" 
                    placeholder="SEO title..." 
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                    value={formData.metaTitle}
                    onChange={(e) => setFormData(prev => ({ ...prev, metaTitle: e.target.value }))}
                    data-testid="input-meta-title"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-dark mb-2" data-testid="label-meta-description">Meta Description</label>
                  <textarea 
                    placeholder="SEO description..." 
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary" 
                    rows={3}
                    value={formData.metaDescription}
                    onChange={(e) => setFormData(prev => ({ ...prev, metaDescription: e.target.value }))}
                    data-testid="textarea-meta-description"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}
