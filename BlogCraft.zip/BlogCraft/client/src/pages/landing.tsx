import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import PostCard from "@/components/post-card";
import { useQuery } from "@tanstack/react-query";
import type { Post } from "@shared/schema";

export default function Landing() {
  const { data: posts = [], isLoading } = useQuery<Post[]>({
    queryKey: ["/api/posts"],
    queryFn: async () => {
      const response = await fetch("/api/posts?limit=6");
      if (!response.ok) throw new Error("Failed to fetch posts");
      return response.json();
    },
  });

  const { data: settings } = useQuery({
    queryKey: ["/api/settings"],
  });

  const featuredPost = posts[0];
  const recentPosts = posts.slice(1, 4);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-primary to-blue-700 text-white py-20" data-testid="hero-section">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6" data-testid="text-hero-title">
              {settings?.siteTagline || "Share Your Stories With The World"}
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-blue-100 max-w-3xl mx-auto" data-testid="text-hero-subtitle">
              {settings?.siteDescription || "A modern blogging platform that helps you create, publish, and manage beautiful content effortlessly."}
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button 
                className="bg-white text-primary px-8 py-3 rounded-lg text-lg font-semibold hover:bg-gray-100 transition-colors"
                data-testid="button-start-reading"
              >
                Start Reading
              </button>
              <a 
                href="/api/login"
                className="border-2 border-white text-white px-8 py-3 rounded-lg text-lg font-semibold hover:bg-white hover:text-primary transition-colors"
                data-testid="button-start-writing"
              >
                Start Writing
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Post */}
      {featuredPost && (
        <section className="py-16 bg-white" data-testid="section-featured">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-dark mb-4" data-testid="text-featured-title">Featured Story</h2>
              <p className="text-medium text-lg" data-testid="text-featured-subtitle">Don't miss our editor's pick for this week</p>
            </div>
            <div className="max-w-4xl mx-auto">
              <article className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow cursor-pointer" data-testid="card-featured-post">
                <div className="md:flex">
                  {featuredPost.featuredImageUrl && (
                    <div className="md:w-1/2">
                      <img 
                        src={featuredPost.featuredImageUrl} 
                        alt={featuredPost.title}
                        className="w-full h-64 md:h-full object-cover"
                        data-testid="img-featured-image"
                      />
                    </div>
                  )}
                  <div className="md:w-1/2 p-8">
                    <div className="flex items-center mb-4">
                      <span className="bg-accent text-white px-3 py-1 rounded-full text-sm font-medium" data-testid="badge-category">
                        Travel
                      </span>
                      <span className="text-medium text-sm ml-4" data-testid="text-read-time">5 min read</span>
                    </div>
                    <h3 className="text-2xl font-bold text-dark mb-4" data-testid="text-featured-post-title">
                      {featuredPost.title}
                    </h3>
                    <p className="text-medium text-lg mb-6" data-testid="text-featured-excerpt">
                      {featuredPost.excerpt}
                    </p>
                    <div className="flex items-center">
                      <div className="w-10 h-10 bg-gray-300 rounded-full mr-4" data-testid="img-author-avatar"></div>
                      <div>
                        <p className="font-semibold text-dark" data-testid="text-author-name">Author</p>
                        <p className="text-medium text-sm" data-testid="text-publish-date">
                          {new Date(featuredPost.publishedAt || featuredPost.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </article>
            </div>
          </div>
        </section>
      )}

      {/* Recent Articles Grid */}
      <section className="py-16 bg-light" data-testid="section-recent">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-dark mb-4" data-testid="text-recent-title">Latest Articles</h2>
            <p className="text-medium text-lg" data-testid="text-recent-subtitle">Fresh perspectives and insights from our community</p>
          </div>
          
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="bg-white rounded-xl shadow-md overflow-hidden animate-pulse">
                  <div className="w-full h-48 bg-gray-300"></div>
                  <div className="p-6">
                    <div className="h-4 bg-gray-300 rounded w-1/4 mb-3"></div>
                    <div className="h-6 bg-gray-300 rounded w-3/4 mb-3"></div>
                    <div className="h-4 bg-gray-300 rounded w-full mb-4"></div>
                    <div className="flex items-center">
                      <div className="w-8 h-8 bg-gray-300 rounded-full mr-3"></div>
                      <div className="h-4 bg-gray-300 rounded w-1/3"></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8" data-testid="grid-recent-posts">
              {recentPosts.map((post) => (
                <PostCard key={post.id} post={post} />
              ))}
            </div>
          )}
          
          <div className="text-center mt-12">
            <button className="bg-primary text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors" data-testid="button-view-all">
              View All Articles
            </button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
