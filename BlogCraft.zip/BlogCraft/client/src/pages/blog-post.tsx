import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import type { Post } from "@shared/schema";

export default function BlogPost() {
  const { slug } = useParams<{ slug: string }>();
  
  const { data: post, isLoading, error } = useQuery<Post>({
    queryKey: ["/api/posts", slug],
    queryFn: async () => {
      const response = await fetch(`/api/posts/${slug}`);
      if (!response.ok) throw new Error("Post not found");
      return response.json();
    },
    enabled: !!slug,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-300 rounded w-1/4 mb-8"></div>
            <div className="h-12 bg-gray-300 rounded w-3/4 mb-6"></div>
            <div className="h-64 bg-gray-300 rounded mb-8"></div>
            <div className="space-y-4">
              <div className="h-4 bg-gray-300 rounded"></div>
              <div className="h-4 bg-gray-300 rounded"></div>
              <div className="h-4 bg-gray-300 rounded w-3/4"></div>
            </div>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  if (error || !post) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-dark mb-4" data-testid="text-error-title">Post Not Found</h1>
            <p className="text-medium mb-8" data-testid="text-error-message">The post you're looking for doesn't exist or has been removed.</p>
            <a href="/" className="bg-primary text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors" data-testid="button-back-home">
              Back to Home
            </a>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Breadcrumb */}
        <nav className="flex mb-8 text-sm" data-testid="breadcrumb">
          <a href="/" className="text-primary hover:text-blue-700" data-testid="link-breadcrumb-home">Home</a>
          <span className="mx-2 text-gray-500">/</span>
          <span className="text-gray-500" data-testid="text-breadcrumb-current">{post.title}</span>
        </nav>

        {/* Article Header */}
        <header className="mb-8">
          <div className="flex items-center mb-4">
            <span className="bg-accent text-white px-3 py-1 rounded-full text-sm font-medium" data-testid="badge-category">
              Article
            </span>
            <span className="text-medium text-sm ml-4" data-testid="text-read-time">5 min read</span>
            <span className="text-medium text-sm ml-4" data-testid="text-publish-date">
              {new Date(post.publishedAt || post.createdAt).toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
              })}
            </span>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-dark mb-6 leading-tight" data-testid="text-post-title">
            {post.title}
          </h1>
          <div className="flex items-center mb-8">
            <div className="w-12 h-12 bg-gray-300 rounded-full mr-4" data-testid="img-author-avatar"></div>
            <div>
              <p className="font-semibold text-dark" data-testid="text-author-name">Author</p>
              <p className="text-medium text-sm" data-testid="text-author-title">Content Creator</p>
            </div>
          </div>
          {post.featuredImageUrl && (
            <img 
              src={post.featuredImageUrl} 
              alt={post.title}
              className="w-full h-64 md:h-96 object-cover rounded-xl shadow-lg"
              data-testid="img-featured-image"
            />
          )}
        </header>

        {/* Article Content */}
        <article className="prose prose-lg max-w-none" data-testid="article-content">
          {post.excerpt && (
            <p className="text-xl text-medium mb-8 font-medium" data-testid="text-post-excerpt">
              {post.excerpt}
            </p>
          )}
          
          <div className="whitespace-pre-wrap text-medium leading-relaxed" data-testid="text-post-content">
            {post.content || "Content will be displayed here..."}
          </div>
        </article>

        {/* Social Sharing */}
        <div className="border-t border-gray-200 pt-8 mt-12" data-testid="section-sharing">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <span className="text-medium font-medium" data-testid="text-share-label">Share this article:</span>
              <button className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors" data-testid="button-share-twitter">
                <i className="fab fa-twitter mr-2"></i>Twitter
              </button>
              <button className="bg-blue-800 text-white px-4 py-2 rounded-md hover:bg-blue-900 transition-colors" data-testid="button-share-facebook">
                <i className="fab fa-facebook mr-2"></i>Facebook
              </button>
              <button className="bg-blue-700 text-white px-4 py-2 rounded-md hover:bg-blue-800 transition-colors" data-testid="button-share-linkedin">
                <i className="fab fa-linkedin mr-2"></i>LinkedIn
              </button>
            </div>
            <button className="text-medium hover:text-primary transition-colors" data-testid="button-bookmark">
              <i className="fas fa-bookmark mr-2"></i>Save
            </button>
          </div>
        </div>

        {/* Author Bio */}
        <div className="bg-light rounded-xl p-8 mt-12" data-testid="section-author-bio">
          <div className="flex items-start">
            <div className="w-20 h-20 bg-gray-300 rounded-full mr-6" data-testid="img-author-profile"></div>
            <div className="flex-1">
              <h3 className="text-xl font-bold text-dark mb-2" data-testid="text-author-bio-name">Author Name</h3>
              <p className="text-medium mb-4" data-testid="text-author-bio-description">
                Professional content creator with expertise in various fields. Passionate about sharing knowledge and insights through engaging storytelling.
              </p>
              <div className="flex space-x-4">
                <a href="#" className="text-primary hover:text-blue-700 transition-colors" data-testid="link-author-twitter">
                  <i className="fab fa-twitter"></i>
                </a>
                <a href="#" className="text-primary hover:text-blue-700 transition-colors" data-testid="link-author-linkedin">
                  <i className="fab fa-linkedin"></i>
                </a>
                <a href="#" className="text-primary hover:text-blue-700 transition-colors" data-testid="link-author-website">
                  <i className="fas fa-globe"></i>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
