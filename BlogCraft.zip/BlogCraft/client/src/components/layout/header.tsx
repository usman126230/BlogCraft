import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import type { Settings } from "@shared/schema";

export default function Header() {
  const { user, isAuthenticated } = useAuth();
  
  const { data: settings } = useQuery<Settings>({
    queryKey: ["/api/settings"],
  });

  return (
    <nav className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50" data-testid="main-navigation">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <a href="/" className="flex items-center" data-testid="link-home">
                {settings?.logoUrl ? (
                  <img 
                    src={settings.logoUrl} 
                    alt={settings.siteTitle || "BlogPro"} 
                    className="h-8 w-auto"
                    data-testid="img-logo"
                  />
                ) : (
                  <h1 className="text-2xl font-bold text-primary" data-testid="text-site-title">
                    {settings?.siteTitle || "BlogPro"}
                  </h1>
                )}
              </a>
            </div>
            <div className="hidden md:block ml-10">
              <div className="flex items-baseline space-x-8">
                <a 
                  href="/" 
                  className="nav-link text-dark hover:text-primary px-3 py-2 text-sm font-medium transition-colors"
                  data-testid="link-nav-home"
                >
                  Home
                </a>
                <a 
                  href="#" 
                  className="nav-link text-medium hover:text-primary px-3 py-2 text-sm font-medium transition-colors"
                  data-testid="link-nav-blog"
                >
                  Blog
                </a>
                <a 
                  href="#" 
                  className="nav-link text-medium hover:text-primary px-3 py-2 text-sm font-medium transition-colors"
                  data-testid="link-nav-about"
                >
                  About
                </a>
                <a 
                  href="#" 
                  className="nav-link text-medium hover:text-primary px-3 py-2 text-sm font-medium transition-colors"
                  data-testid="link-nav-contact"
                >
                  Contact
                </a>
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            {isAuthenticated ? (
              <>
                <a 
                  href="/admin"
                  className="bg-primary text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-blue-700 transition-colors"
                  data-testid="button-dashboard"
                >
                  <i className="fas fa-tachometer-alt mr-2"></i>Dashboard
                </a>
                <div className="hidden md:block">
                  <div className="relative">
                    <div className="flex items-center" data-testid="user-menu">
                      {user?.profileImageUrl ? (
                        <img 
                          className="h-8 w-8 rounded-full object-cover" 
                          src={user.profileImageUrl} 
                          alt="User avatar"
                          data-testid="img-user-avatar"
                        />
                      ) : (
                        <div className="h-8 w-8 rounded-full bg-primary text-white flex items-center justify-center text-sm font-medium" data-testid="avatar-placeholder">
                          {(user?.firstName?.[0] || user?.email?.[0] || 'U').toUpperCase()}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </>
            ) : (
              <a 
                href="/api/login"
                className="bg-primary text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-blue-700 transition-colors"
                data-testid="button-login"
              >
                Sign In
              </a>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}
