import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import type { Settings } from "@shared/schema";

interface AdminLayoutProps {
  children: React.ReactNode;
}

export default function AdminLayout({ children }: AdminLayoutProps) {
  const { user } = useAuth();
  const [location] = useLocation();
  
  const { data: settings } = useQuery<Settings>({
    queryKey: ["/api/settings"],
  });

  const isActive = (path: string) => {
    return location === path || location.startsWith(path);
  };

  const navLinks = [
    {
      path: "/admin/dashboard",
      icon: "fas fa-tachometer-alt",
      label: "Dashboard",
      testId: "nav-dashboard"
    },
    {
      path: "/admin/posts",
      icon: "fas fa-file-alt",
      label: "Posts",
      testId: "nav-posts"
    },
    {
      path: "/admin/posts/new",
      icon: "fas fa-edit",
      label: "New Post",
      testId: "nav-new-post"
    },
    {
      path: "/admin/settings",
      icon: "fas fa-cog",
      label: "Settings",
      testId: "nav-settings"
    },
    {
      path: "/admin/profile",
      icon: "fas fa-user",
      label: "Profile",
      testId: "nav-profile"
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Admin Navigation */}
      <nav className="bg-white shadow-sm border-b border-gray-200" data-testid="admin-navigation">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <a href="/admin" className="flex items-center" data-testid="link-admin-home">
                {settings?.logoUrl ? (
                  <img 
                    src={settings.logoUrl} 
                    alt="Logo" 
                    className="h-8 w-auto mr-3"
                    data-testid="img-admin-logo"
                  />
                ) : (
                  <div className="w-8 h-8 bg-primary rounded flex items-center justify-center text-white font-bold text-sm mr-3">
                    {(settings?.siteTitle?.[0] || 'B')}
                  </div>
                )}
                <h1 className="text-2xl font-bold text-primary" data-testid="text-admin-title">
                  {settings?.siteTitle || "BlogPro"} Admin
                </h1>
              </a>
            </div>
            <div className="flex items-center space-x-4">
              <a 
                href="/"
                className="text-medium hover:text-primary transition-colors"
                data-testid="link-view-site"
              >
                <i className="fas fa-external-link-alt mr-2"></i>View Site
              </a>
              <a 
                href="/api/logout"
                className="text-medium hover:text-red-600 transition-colors"
                data-testid="link-logout"
              >
                <i className="fas fa-sign-out-alt mr-2"></i>Logout
              </a>
              <div className="relative">
                <div className="flex items-center" data-testid="admin-user-menu">
                  {user?.profileImageUrl ? (
                    <img 
                      className="h-8 w-8 rounded-full object-cover" 
                      src={user.profileImageUrl} 
                      alt="Admin avatar"
                      data-testid="img-admin-avatar"
                    />
                  ) : (
                    <div className="h-8 w-8 rounded-full bg-primary text-white flex items-center justify-center text-sm font-medium" data-testid="admin-avatar-placeholder">
                      {(user?.firstName?.[0] || user?.email?.[0] || 'A').toUpperCase()}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </nav>

      <div className="flex h-screen bg-gray-50">
        {/* Sidebar */}
        <div className="w-64 bg-white shadow-lg" data-testid="admin-sidebar">
          <nav className="mt-8">
            <div className="px-4">
              <ul className="space-y-2">
                {navLinks.map((link) => (
                  <li key={link.path}>
                    <a 
                      href={link.path}
                      className={`flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-colors ${
                        isActive(link.path)
                          ? 'bg-blue-50 text-primary border-r-2 border-primary'
                          : 'text-medium hover:text-primary hover:bg-gray-50'
                      }`}
                      data-testid={link.testId}
                    >
                      <i className={`${link.icon} mr-3`}></i>
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          </nav>
        </div>

        {/* Main Content */}
        <div className="flex-1 overflow-auto" data-testid="admin-main-content">
          {children}
        </div>
      </div>
    </div>
  );
}
