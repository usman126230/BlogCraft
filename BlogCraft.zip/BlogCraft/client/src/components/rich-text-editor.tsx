import { useState } from "react";

interface RichTextEditorProps {
  value: string;
  onChange: (content: string) => void;
  placeholder?: string;
}

export default function RichTextEditor({ value, onChange, placeholder = "Start writing..." }: RichTextEditorProps) {
  const [isPreview, setIsPreview] = useState(false);

  const insertText = (before: string, after: string = "") => {
    const textarea = document.querySelector('[data-testid="editor-textarea"]') as HTMLTextAreaElement;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = value.substring(start, end);
    const newText = value.substring(0, start) + before + selectedText + after + value.substring(end);
    
    onChange(newText);
    
    // Reset cursor position
    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(start + before.length, end + before.length);
    }, 0);
  };

  const formatSelection = (format: string) => {
    switch (format) {
      case 'bold':
        insertText('**', '**');
        break;
      case 'italic':
        insertText('*', '*');
        break;
      case 'underline':
        insertText('<u>', '</u>');
        break;
      case 'h1':
        insertText('# ');
        break;
      case 'h2':
        insertText('## ');
        break;
      case 'h3':
        insertText('### ');
        break;
      case 'link':
        insertText('[', '](url)');
        break;
      case 'image':
        insertText('![alt text](image-url)');
        break;
      case 'quote':
        insertText('> ');
        break;
      case 'unordered-list':
        insertText('- ');
        break;
      case 'ordered-list':
        insertText('1. ');
        break;
      case 'code':
        insertText('`', '`');
        break;
      case 'code-block':
        insertText('```\n', '\n```');
        break;
    }
  };

  const renderPreview = (content: string) => {
    // Basic markdown-to-HTML conversion for preview
    let html = content
      .replace(/^### (.*$)/gim, '<h3>$1</h3>')
      .replace(/^## (.*$)/gim, '<h2>$1</h2>')
      .replace(/^# (.*$)/gim, '<h1>$1</h1>')
      .replace(/\*\*(.*)\*\*/gim, '<strong>$1</strong>')
      .replace(/\*(.*)\*/gim, '<em>$1</em>')
      .replace(/!\[([^\]]*)\]\(([^\)]*)\)/gim, '<img alt="$1" src="$2" />')
      .replace(/\[([^\]]*)\]\(([^\)]*)\)/gim, '<a href="$2">$1</a>')
      .replace(/^> (.*$)/gim, '<blockquote>$1</blockquote>')
      .replace(/`([^`]*)`/gim, '<code>$1</code>')
      .replace(/```\n([\s\S]*?)\n```/gim, '<pre><code>$1</code></pre>')
      .replace(/^\- (.*$)/gim, '<li>$1</li>')
      .replace(/^\d+\. (.*$)/gim, '<li>$1</li>')
      .replace(/\n/gim, '<br>');

    return html;
  };

  return (
    <div className="border border-gray-300 rounded-lg overflow-hidden" data-testid="rich-text-editor">
      {/* Toolbar */}
      <div className="border-b border-gray-300 p-3 bg-gray-50 rounded-t-lg" data-testid="editor-toolbar">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-1">
            {/* Text formatting */}
            <button 
              type="button"
              onClick={() => formatSelection('bold')}
              className="p-2 hover:bg-gray-200 rounded transition-colors"
              title="Bold"
              data-testid="button-bold"
            >
              <i className="fas fa-bold"></i>
            </button>
            <button 
              type="button"
              onClick={() => formatSelection('italic')}
              className="p-2 hover:bg-gray-200 rounded transition-colors"
              title="Italic"
              data-testid="button-italic"
            >
              <i className="fas fa-italic"></i>
            </button>
            <button 
              type="button"
              onClick={() => formatSelection('underline')}
              className="p-2 hover:bg-gray-200 rounded transition-colors"
              title="Underline"
              data-testid="button-underline"
            >
              <i className="fas fa-underline"></i>
            </button>

            <div className="w-px h-6 bg-gray-300 mx-1"></div>

            {/* Headings */}
            <button 
              type="button"
              onClick={() => formatSelection('h1')}
              className="p-2 hover:bg-gray-200 rounded transition-colors text-sm font-bold"
              title="Heading 1"
              data-testid="button-h1"
            >
              H1
            </button>
            <button 
              type="button"
              onClick={() => formatSelection('h2')}
              className="p-2 hover:bg-gray-200 rounded transition-colors text-sm font-bold"
              title="Heading 2"
              data-testid="button-h2"
            >
              H2
            </button>
            <button 
              type="button"
              onClick={() => formatSelection('h3')}
              className="p-2 hover:bg-gray-200 rounded transition-colors text-sm font-bold"
              title="Heading 3"
              data-testid="button-h3"
            >
              H3
            </button>

            <div className="w-px h-6 bg-gray-300 mx-1"></div>

            {/* Lists */}
            <button 
              type="button"
              onClick={() => formatSelection('unordered-list')}
              className="p-2 hover:bg-gray-200 rounded transition-colors"
              title="Bullet List"
              data-testid="button-ul"
            >
              <i className="fas fa-list-ul"></i>
            </button>
            <button 
              type="button"
              onClick={() => formatSelection('ordered-list')}
              className="p-2 hover:bg-gray-200 rounded transition-colors"
              title="Numbered List"
              data-testid="button-ol"
            >
              <i className="fas fa-list-ol"></i>
            </button>

            <div className="w-px h-6 bg-gray-300 mx-1"></div>

            {/* Insert elements */}
            <button 
              type="button"
              onClick={() => formatSelection('link')}
              className="p-2 hover:bg-gray-200 rounded transition-colors"
              title="Insert Link"
              data-testid="button-link"
            >
              <i className="fas fa-link"></i>
            </button>
            <button 
              type="button"
              onClick={() => formatSelection('image')}
              className="p-2 hover:bg-gray-200 rounded transition-colors"
              title="Insert Image"
              data-testid="button-image"
            >
              <i className="fas fa-image"></i>
            </button>
            <button 
              type="button"
              onClick={() => formatSelection('quote')}
              className="p-2 hover:bg-gray-200 rounded transition-colors"
              title="Quote"
              data-testid="button-quote"
            >
              <i className="fas fa-quote-right"></i>
            </button>
            <button 
              type="button"
              onClick={() => formatSelection('code')}
              className="p-2 hover:bg-gray-200 rounded transition-colors"
              title="Inline Code"
              data-testid="button-code"
            >
              <i className="fas fa-code"></i>
            </button>
          </div>

          {/* Preview toggle */}
          <button 
            type="button"
            onClick={() => setIsPreview(!isPreview)}
            className={`px-3 py-1 rounded text-sm font-medium transition-colors ${
              isPreview 
                ? 'bg-primary text-white' 
                : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
            }`}
            data-testid="button-preview-toggle"
          >
            {isPreview ? 'Edit' : 'Preview'}
          </button>
        </div>
      </div>

      {/* Editor Content */}
      <div className="p-6">
        {isPreview ? (
          <div 
            className="prose max-w-none min-h-96"
            dangerouslySetInnerHTML={{ __html: renderPreview(value) }}
            data-testid="editor-preview"
          />
        ) : (
          <textarea
            placeholder={placeholder}
            className="w-full h-96 border-none resize-none focus:outline-none text-medium leading-relaxed"
            style={{ fontFamily: 'inherit' }}
            value={value}
            onChange={(e) => onChange(e.target.value)}
            data-testid="editor-textarea"
          />
        )}
      </div>

      {/* Help text */}
      <div className="px-6 pb-4 text-xs text-gray-500" data-testid="editor-help">
        <p>
          Tip: Use Markdown formatting. **bold**, *italic*, # heading, [link](url), ![image](url)
        </p>
      </div>
    </div>
  );
}
