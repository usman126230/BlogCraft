import type { Post } from "@shared/schema";

interface PostCardProps {
  post: Post;
}

export default function PostCard({ post }: PostCardProps) {
  const publishDate = new Date(post.publishedAt || post.createdAt);
  
  return (
    <article 
      className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow cursor-pointer" 
      data-testid={`card-post-${post.id}`}
    >
      <a href={`/post/${post.slug}`} className="block">
        {post.featuredImageUrl && (
          <img 
            src={post.featuredImageUrl} 
            alt={post.title}
            className="w-full h-48 object-cover"
            data-testid="img-post-featured"
          />
        )}
        <div className="p-6">
          <div className="flex items-center mb-3">
            <span className="bg-blue-100 text-primary px-3 py-1 rounded-full text-sm font-medium" data-testid="badge-post-category">
              {post.categoryId || 'Uncategorized'}
            </span>
            <span className="text-medium text-sm ml-3" data-testid="text-read-time">
              {Math.max(1, Math.ceil((post.content?.length || 0) / 250))} min read
            </span>
          </div>
          <h3 className="text-xl font-semibold text-dark mb-3" data-testid="text-post-card-title">
            {post.title}
          </h3>
          {post.excerpt && (
            <p className="text-medium mb-4" data-testid="text-post-card-excerpt">
              {post.excerpt.length > 120 ? `${post.excerpt.substring(0, 120)}...` : post.excerpt}
            </p>
          )}
          <div className="flex items-center">
            <div className="w-8 h-8 bg-gray-300 rounded-full mr-3" data-testid="img-post-author-avatar">
              {/* Author avatar placeholder */}
            </div>
            <div>
              <p className="font-medium text-dark text-sm" data-testid="text-post-author">
                Author
              </p>
              <p className="text-medium text-xs" data-testid="text-post-date">
                {publishDate.toLocaleDateString('en-US', {
                  year: 'numeric',
                  month: 'short',
                  day: 'numeric'
                })}
              </p>
            </div>
          </div>
          {post.viewCount && post.viewCount > 0 && (
            <div className="mt-3 pt-3 border-t border-gray-100">
              <span className="text-xs text-medium flex items-center" data-testid="text-view-count">
                <i className="fas fa-eye mr-1"></i>
                {post.viewCount.toLocaleString()} views
              </span>
            </div>
          )}
        </div>
      </a>
    </article>
  );
}
